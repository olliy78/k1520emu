;Version f�r A5120/K8924 u.�. unter CP/A, SCPX
;-------------------------------------------------
;GER�ST F�R STC-PLAYER MIT INCLUDE-DATEI
;ASSEMBLER: ASIDE
;WERO, 08/2017
;-------------------------------------------------
; Version 1.2.0.1 f�r CP/A, SCPX, u.�.
; KW 16.12.2017 (Klaus Wilfling)
;
; Song wird gestarte und Programm beendet (l�uft im Hintergrund)
; IO-Adresse 38h
;-------------------------------------------------
;ZUN�CHST ANPASSUNG DER AYPBC.INC (AYPLAY.INC von WERO) 
;AN JEWEILIGES SYSTEM VORNEHMEN:
;HINWEIS CTC-PROGRAMMIERUNG BEACHTEN!
;X0001:   EQU    #aa              ;AY-BASISADRESSE ANPASSEN
;X0002:   EQU    #cc              ;CTC-BASISADRESSE ANPASSEN
;X0003:   EQU    #IIII            ;INTERRUPTTABELLE CTC 
;-------------------------------------------------
START:    EQU     100h            ;PROGRAMMSTART CP/M
WORK:     EQU     0110h           ;BEGINN ARBEITSZELLEN (50h)
PLAYER:   EQU     WORK+0050h      ;BEGINN PLAYER-ENGINE (480h)
PROGGI:   EQU     PLAYER+0480h    ;PROGRAMMBEGINN
WDH:      EQU     WORK+02         ;BYTE, ANZAHL WIEDERHOLUNGEN
;
ANZ_WDH:  EQU     2               ;ANZAHL WIEDERHOLUNGEN
;
;-------------------------------------------------
ORG       START                   ;Anfang CP/M
          JP      START0
;-------------------------------------------------
ORG       WORK                    ;ARBEITSZELLEN, BEZ�GE:
          ;WORK                   ;WORD, �BERGABE ANFANGSADESSE SONG
          ;WORK+2                 ;BYTE, �BERGABE ANZAHL ABSPIELE
                                  ;(1...255, 0 BEI SONGENDE)
;-------------------------------------------------
ORG       PLAYER                  ;BEZ�GE:
          ;PLAYER+0               ;SONG LADEN+ABSPIELEN
          ;PLAYER+6               ;SOUND AUS
;-------------------------------------------------
INCLUDE   AYPBC.INC               ;AY-PLAYER-ENGINE
;-------------------------------------------------
ORG       PROGGI
START0:   ;...HIER ANWENDERPROGRAMM
          ;...VORARBEITEN...
          ;
          ;SONG LADEN, SPIELEN, STOPPEN:
          LD      HL,SONG         ;ANFANGSADRESSE SONG
          LD      (WORK),HL       ;�BERGEBEN
          LD      A,ANZ_WDH       ;ANZAHL ABSPIELE (Z.B. 2x)
          LD      (WDH),A         ;�BERGEBEN
          CALL    PLAYER          ;SONG ABSPIELEN
          ;...SONG L�UFT SELSTBST�NDIG WEITER!
          ;NUN IRGEND ETWAS TUN...ODER AUCH NICHT...
          ;WENN SONG ZUENDE, WIRD INTERRUPT AUTOMATISCH GESTOPPT
          ;
          ;CALL   PLAYER+6        ;SONG VORZEITIG STOPPEN 
          ;...
          RET                     ;R�CKKEHR ZUM OS
;-------------------------------------------------
SONG:   
INCLUDEBINARY MUSIC.STC         ;HIER ABZUSPIELENDEN SONG EINBINDEN
