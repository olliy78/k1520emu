;Version f�r A5120/K8924 u.�.
;-------------------------------------------------
;GER�ST F�R STC-PLAYER MIT INCLUDE-DATEI
;ASSEMBLER: ASIDE
;WERO, 08/2017
;-------------------------------------------------
; Version 1.2.0.2 f�r CP/A, SCPX, u.�.
; KW 28.12.2017 (Klaus Wilfling)
;
;Programmaufruf z.B: PLAYSTC S1.STC
;
;Song wird geladen gestartet und Programm beendet 
;l�uft im Hintergrund weiter
;-------------------------------------------------
;ZUN�CHST ANPASSUNG DER AYPLAY.INC 
;AN JEWEILIGES SYSTEM VORNEHMEN:
;HINWEIS CTC-PROGRAMMIERUNG BEACHTEN!
;X0001:  EQU    #aa             ;AY-BASISADRESSE ANPASSEN
;X0002:  EQU    #cc             ;CTC-BASISADRESSE ANPASSEN
;X0003:  EQU    #IIII           ;INTERRUPTTABELLE CTC 
;-------------------------------------------------
START:    EQU    100h            ;PROGRAMMSTART CP/M
WORK:     EQU    START+10h       ;BEGINN ARBEITSZELLEN (50h)
PLAYER:   EQU    WORK+50h        ;BEGINN PLAYER-ENGINE (480h)
PROGGI:   EQU    PLAYER+480h     ;PROGRAMMBEGINN
WDH:      EQU    WORK+2          ;ABSPIELE

ANZ_WDH:  EQU    2               ;ANZAHL ABSPIELE

;f�r CP/M
bdos:     equ    5
fcb:      equ    5Ch
fcb_ext:  equ    65h
dma:      equ    80h

;-------------------------------------------------
ORG       START                  ;
          JP      START0
;-------------------------------------------------
ORG       WORK                   ;ARBEITSZELLEN, BEZ�GE:
          ;WORK                  ;WORD, �BERGABE ANFANGSADESSE SONG
          ;WORK+2                ;BYTE, �BERGABE ANZAHL ABSPIELE
                                 ;(1...255, 0 BEI SONGENDE)
;-------------------------------------------------
ORG       PLAYER                 ;BEZ�GE:
          ;PLAYER+0              ;SONG LADEN+ABSPIELEN
          ;PLAYER+6              ;SOUND AUS
;-------------------------------------------------
INCLUDE   AYPBC.INC              ;AY-PLAYER-ENGINE
;-------------------------------------------------
ORG       PROGGI
START0:   ;...HIER ANWENDERPROGRAMM
          ;...VORARBEITEN...
          ;
s_load:   ld     de,fcb
          ld     c,0Fh           ;Datei �ffnen
          call   bdos                
          inc    a               ;bei 0FFh -> Datei nicht gefunden
          jr     nz,s_load1      ;Datei vorhanden -> weiter
          ld     de,s_loaderr2   ;"Datei kann nicht ge�ffnet werden"
          ld     c,09h           ;Zeichenkette ausgeben
          call   bdos                
          ret  
               
;pr�fen ob es eine STC Datei ist
;Datei in Ziel-Puffer schreiben
s_load1:  ld    hl,fcb_ext
          ld    a,(hl)
          cp    'S'
          jr    nz,s_loadx
          inc   hl
          ld    a,(hl)
          cp    'T'
          jr    nz,s_loadx
          inc   hl
          ld    a,(hl)
          cp    'C'
          jr    nz,s_loadx

          ld    hl,sp_anf        ;Song-Puffer-Anfang
          ld    (sp_zei),hl      ;Zeiger Song-Puffer

s_load3:  ld    de,fcb
          ld    c,14h            ;sequentiell lesen
          call  bdos
          and   a                ;00 = lesen ok
          jr    nz,play          ;NZ = Dateiende
          ld    hl,dma           ;Quelle DMA
          ld    de,(sp_zei)      ;Ziel im Song-Puffer
          ld    bc,80h           ;Laenge
          ldir                   ;umladen
          ld    (sp_zei),de      ;Zeiger merken
          jr    s_load3

s_loadx:  ld    de,s_loaderr1    ;"Falsches Dateiformat"
          ld    c,09h            ;Zeichenkette ausgeben
          call  bdos                
          ret
 
        ;SONG LADEN, SPIELEN, STOPPEN:
play:     ld    de,text
          ld    c,09h            ;Zeichenkette ausgeben
          call  bdos

          LD    HL,sp_anf        ;ANFANGSADRESSE SONG
          LD    (WORK),HL        ;�BERGEBEN
          LD    A,ANZ_WDH        ;ANZAHL ABSPIELE (Z.B. 2x)
          LD    (WDH),A          ;�BERGEBEN
          CALL  PLAYER           ;SONG ABSPIELEN
          ;...SONG L�UFT SELSTBST�NDIG WEITER!
          ;NUN IRGEND ETWAS TUN...ODER AUCH NICHT...
          ;WENN SONG ZUENDE, WIRD INTERRUPT AUTOMATISCH GESTOPPT
          ;
          ;CALL   PLAYER+6       ;SONG VORZEITIG STOPPEN 
          ;...
          RET                    ;R�CKKEHR ZUM OS
;-------------------------------------------------
text:     defm 'Song wird gespielt und laeuft im Hintergrund weiter',0dh,0ah
          defm '... 1 Wiederholung... ',0dh,0ah,
          defm 0dh,0ah,
          defm 'Abbruch zur Zeit nur mit RESET ;-( ',0dh, 0ah
          defm 'oder warten bis der Song zu Ende ist... $'
          
s_loaderr1: defm 'Falsches Dateiformat ... muss .STC sein!$'
s_loaderr2: defm 'Datei kann nicht geoeffnet werden!',0dh,0ah
            defm 'Datei nicht vorhanden oder Dateiname falsch!',0dh,0ah 
            defm '... Dateiname mit Endung .STC angeben...$'
            
sp_zei:   defw  0                ;Zeiger Song-Puffer
sp_anf:   defs  0 ;defs  8192    ;Song Puffer
                  ;hierher wird der Song geladen
                  ;manche Songs k�nnen bis zu 8192 Byte gro� sein

