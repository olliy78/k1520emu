copy /b "cpmstcpl.bin" "CPMSTCPL.COM"
