copy /b "cpmpt3pl.bin" "CPMPT3PL.COM"
