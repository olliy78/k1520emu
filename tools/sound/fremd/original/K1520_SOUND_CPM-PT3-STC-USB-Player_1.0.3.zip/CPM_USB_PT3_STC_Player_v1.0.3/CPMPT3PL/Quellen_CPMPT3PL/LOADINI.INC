          ;
          ;LDINI.INC - INI-Datei suchen und wenn vorhanden laden
          ;arbeitet mit dem STDMA (80h) und FCB (5Dh)
          ;
          ;Von hier aus werden die Patch-Routinen aufgerufen.
          ;Diese muessen im Hauptprogramm als UP vorhanden sein.
          ;Wird keine INI-Datei gefunden dann Rueckkehr mit CY=1
          ;
          ; 18. Februar 2018, H. Poppe
          ;
          ; Funktion:
          ; Programm wird direkt nach Start aufgerufen
          ;
          ; Rueckkehr mit CY = 1 wenn keine INI-Datei
          ; gefunden wird, dann wird die Konfiguration 
          ; abgefragt
          ;
          ; Bei Rueckkehr mit CY = 0 wird die Abfrage
          ; der Konfiguration uebersprungen, es werden
          ; die Werte aus der INI-Datei verwendet
          ;
bdos:       equ 5                 ;BDOS-Aufruf
fcb:        equ 5Ch               ;Standard-FCB
stdma:      equ 80h               ;Standard-DMA
            ;
ldini:      call fcbclr           ;FCB leeren
            ld b,8                ;Laenge Name
            ld hl,inifil          ;Dateiname
            ld de,fcb             ;Quell-FCB
            inc de                ;LW ueberspringen
ldin1:      ld a,(hl)
            cp '.'
            jr z,ldin2
            ld (de),a
            inc hl
ldin2:      inc de
            djnz ldin1
            inc hl
            ld bc,3
            ldir
            ld de,fcb
            ld c,0Fh              ;Datei oeffnen, FF=Fehler
            call bdos
            cp 0FFh
            jr z,lderr            ;1: keine INI-Datei
            ld de,fcb
            ld c,14h              ;sequentiell lesen
            call bdos             ;00 = lesen ok
            and a
            jr nz,lderr           ;2: Lesefehler
            ld de,fcb
            ld c,10h              ;Datei schliessen
            call bdos
            ld de,stdma
            ld hl,inifi1
            ld b,3
ldin3:      ld a,(de)             ;Kennung vergleichen
            and 0DFh              ;klein > GROSS
            cp (hl)
            jr nz,lderr           ;3: keine Kennung
            inc hl
            inc de
            djnz ldin3
            ex de,hl              ;Quelle in HL
            ld b,(hl)             ;Adresse Soundkarte
            inc hl
            ld c,(hl)             ;Zeitkonstante CTC
            inc hl
            ld e,(hl)
            inc hl
            ld d,(hl)
            inc hl
            ex de,hl
            call sysset           ;Patchen der Systemadressen
            ex de,hl
            ld b,(hl)             ;Adresse USB-PIO
            call usbset           ;Patchen der USB-Adressen
            and a                 ;OK: CY=0
            ret
            ;
lderr:      scf                   ;Fehler: CY=1
            ret
            ;
            ; FCB leeren und Satznummern auf Anfang
            ;
fcbclr:     ld hl,fcb             ;Je 40 Zeichen Laenge
fcbcl1:     ld (hl),0             ;LW und User auf 0
            ld b,11
fcbcl2:     inc hl
            ld (hl),20h           ;Namensfeld leeren
            djnz fcbcl2
            ld b,28
fcbcl3:     inc hl
            ld (hl),0             ;Rest auf 0
            djnz fcbcl3
            ret
            ;
inifil:     defm 'SOUND.'         ;Name INI-Datei
inifi1:     defm 'INI'
            ;
          
