program SNDINIT_PAS;

type  bytes = string[2];

var   ibyte, rbyte : array[1..8] of bytes;
      mhzread : real;
      taste : char;
      inter : string[4];
      mhzein : string[6];
      ausgabe, zeile : string[128];
      datei : text;
      schreib : boolean;
      mhz : real;
      stat : integer;
      i : byte;

function hex2dec(hexbit : char) : byte;
var bit : byte;
begin
  if ord(hexbit) < 58 then
  begin
    bit := ord(hexbit)-48
  end
  else
  begin
    case upcase(hexbit) of
      'A' : bit := 10;
      'B' : bit := 11;
      'C' : bit := 12;
      'D' : bit := 13;
      'E' : bit := 14;
      'F' : bit := 15
    end
  end;
  hex2dec := bit
end;

function dec2hex(dec : byte) : bytes;
var ze : array[1..2] of byte;
    bit : array[1..2] of bytes;
    i : byte;
begin
  ze[1] := dec mod 16;
  ze[2] := (dec div 16) mod 16;
  for i := 1 to 2 do
  begin
    if ze[i] < 10 then
    begin
      str(ze[i],bit[i])
    end
    else
    begin
      case ze[i] of
        10 : bit[i] := 'A';
        11 : bit[i] := 'B';
        12 : bit[i] := 'C';
        13 : bit[i] := 'D';
        14 : bit[i] := 'E';
        15 : bit[i] := 'F'
      end
    end
  end;
  dec2hex := concat(bit[2],bit[1]);
end;

function hex2ascii(hexstring : bytes) : char;
var lowbit, highbit : string[1];
begin
  lowbit := copy(hexstring,2,1);
  highbit := copy(hexstring,1,1);
  hex2ascii := chr(16*hex2dec(highbit)+hex2dec(lowbit))
end;

function errorcheck(eingabe : bytes) : boolean;
const error = 'Falscher Adressbereich -> erneute Eingabe!';
var checkbit : byte;
    ok : boolean;
    i : byte;
begin
  if length(eingabe) = 2 then
  begin
    for i:=1 to 2 do
    begin
      checkbit := ord(upcase(copy(eingabe,i,1)));
      if ((checkbit > 47) and (checkbit < 58))
      or ((checkbit > 64) and (checkbit < 71))
      then ok := true else ok := false
    end
  end
  else ok := false;
  if not ok then writeln(error);
  errorcheck := ok
end;

function mhzcheck(eingabe : real) : boolean;
const error = 'Die CPU-Frequenz muss groesser 0 und kleiner 3.27 MHz sein!';
var ok : boolean;
begin
  if (eingabe > 0) and (eingabe <= 3.27) then ok := true
  else
  begin
    ok := false;
    writeln(error)
  end;
  mhzcheck := ok
end;


begin
  clrscr;
  ibyte[1] := 'I';
  ibyte[2] := 'N';
  ibyte[3] := 'I';
  zeile := '';
  writeln('*********************************************************');
  writeln('**   SOUND.INI-Generator V 2.o fuer K152o-Soundkarte   **');
  writeln('**         geschrieben von Spaceman, o4.o3.2o18        **');
  writeln('**     weitere Informationen unter www.k152o.8i8.de    **');
  writeln('*********************************************************');
  writeln;
  assign(datei,'SOUND.INI');
  (*$I-*) reset (datei); (*$I+*)
  if ioresult = 0 then
  begin
    writeln('Es existiert bereits eine SOUND.INI-Datei. Vorhandene');
    writeln('Werte werden in Klammern angezeigt und bei ENTER als');
    writeln('neue Eingabewerte uebernommen.');
    writeln;
    readln(datei,zeile);
    for i := 4 to 8 do
    begin
      if i = 5 then
      begin
        mhzread := (round(ord(copy(zeile,5,1))*5/1000*256+0.5)/100);
      end
      else
      begin
        rbyte[i] := dec2hex(ord(copy(zeile,i,1)))
      end
    end
  end;
  repeat
    write('Basis-Adresse AY-Chip (zwischen 00 und FF Hex) ');
    if zeile <> '' then write('(',rbyte[4],')');
    write(' : ');
    buflen := 2;
    readln(ibyte[4]);
    if ibyte[4] = '' then ibyte[4] := rbyte[4]
  until errorcheck(ibyte[4]);
  repeat
    write('CPU-Frequenz (zw. 0 und 3.27 MHz, z.B. 2.46) ');
    if zeile <> '' then write('(',mhzread:1:2,')') else write ('  ');
    write(' : ');
    buflen := 4;
    readln(mhzein);
    if mhzein = '' then str(mhzread:8,mhzein);
    val(mhzein,mhz,stat);
    if stat <> 0 then
    begin
      val(concat(copy(mhzein,1,stat-1),'.',copy(mhzein,stat+1,length(mhzein)-stat)),mhz,stat);
    end;
  until mhzcheck(mhz);
  ibyte[5] := chr(round(mhz*1000*1000/256/50-0.5));
  (* writeln(round(mhz*1000*1000/256/50-0.5)); *)
  repeat
    write('Adresse Interruptsaeule (in HEX 4-stellig)   ');
    if zeile <> '' then
    begin
      write('(',rbyte[6],rbyte[7],')')
    end
    else write('  ');
    write(' : ');
    buflen := 4;
    readln(inter);
    ibyte[6] := copy(inter,3,2);
    if ibyte[6] = '' then ibyte[6] := rbyte[7];
    ibyte[7] := copy(inter,1,2);
    if ibyte[7] = '' then ibyte[7] := rbyte[6]
  until errorcheck(ibyte[6]) and errorcheck(ibyte[7]);
  repeat
    write('Adresse USB-PIO (zwischen 00 und FF Hex)       ');
    if zeile <> '' then write('(',rbyte[8],')');
    write(' : ');
    buflen := 2;
    readln(ibyte[8]);
    if ibyte[8] = '' then ibyte[8] := rbyte[8]
  until errorcheck(ibyte[8]);
  ausgabe:=concat(ibyte[1],ibyte[2],ibyte[3]);
  ausgabe:=concat(ausgabe,hex2ascii(ibyte[4]),ibyte[5],hex2ascii(ibyte[7]));
  ausgabe:=concat(ausgabe,hex2ascii(ibyte[6]),hex2ascii(ibyte[8]));
  for i:=8 to 126 do ausgabe:=concat(ausgabe,hex2ascii('00'));
  writeln;
  if zeile <> '' then
  begin
    write('Datei SOUND.INI ueberschreiben (J/N)? ');
    buflen := 1;
    readln(taste);
    writeln;
    if upcase(taste) = 'J' then schreib := true else schreib := false
  end else schreib := true;
  if schreib then
  begin
    write('Datei SOUND.INI (',copy(ausgabe,1,8),') wird erstellt...');
    rewrite(datei);
    write(datei,ausgabe);
    writeln('fertig.')
  end;
  close(datei)
end.