copy /b "bicpt3pl.bin" "BICPT3PL.COM"
copy /b "bicstcpl.bin" "BICSTCPL.COM"
copy /b "playstc.bin" "PLAYSTC.COM"
copy /b "playpt3.bin" "PLAYPT3.COM"
