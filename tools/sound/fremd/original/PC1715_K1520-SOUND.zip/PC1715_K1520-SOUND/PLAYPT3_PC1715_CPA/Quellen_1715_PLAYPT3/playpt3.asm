;-------------------------------------------------
;PLAYPT3
;-------------------------------------------------
;Version f�r PC1715
;-------------------------------------------------
;GER�ST F�R STC-PLAYER MIT INCLUDE-DATEI
;ASSEMBLER: ASIDE
;Version 1.0.0.1
;WERO, 08/2017
;KW 26.10.2019 (Klaus Wilfling)
;-------------------------------------------------
;
;Version 1.0.0.2 
;KW 25.11.2025
;IO-Adresse der Soundkarte f�r PC1715 ge�ndert
;
;
;Programmaufruf z.B: PLAYPT3 SONG1.PT3
;
;-------------------------------------------------
;Adressen evtl. an verwendete Hardware anpassen!!!
AYBAS:      EQU     0E0H
CTCBAS:     EQU     AYBAS+4   ;CTC-BASISADRESSE
CTCZK:      EQU     192       ;CTC ZK 0
CTCINT:     EQU     0F7F0H    ;f�r 1715 CP/A ;ADRESSE INTERRUPTTABELLE, CTC Kanal 0 
;-------------------------------------------------

START:     EQU    100h          ;PROGRAMMSTART CP/M
;PLAYERANF: EQU    01000h        ;Adresser der Player-Engine

;f�r CP/M
bdos:      equ    5
fcb:       equ    5Ch
fcb_ext:   equ    65h
dma:       equ    80h

;-------------------------------------------------
ORG       START 

;lokalen Stack einrichten
            LD      (SPSV),SP     ;Stackpointer merken
            LD      SP, STACK     ;lokaler Stack               
            JP      START0
;
MODNR:      DEFB    0           ;BYTE, MODUS: 0=EINZEL, 
                                ;1=PLAYLISTE,2=REIHE,3=ZUFALL
ASCII:      DEFW    0           ;WORD,  BWS-ADRESSE SEL. EINTRAG
TICKS:      DEFW    0           ;SPIELDAUER IN INTERRUPTS
SNR:        DEFW    0           ;WORD, AKT. SONGNUMMER
CURPOS:     DEFW    0000h
;
START0:   xor    a
          ld     (pause),a      ;nicht pausieren

s_load:   ld     de,fcb
          ld     c,0Fh          ;Datei �ffnen
          call   bdos                
          inc    a              ;bei 0FFh -> Datei nicht gefunden
          jr     nz,s_load1     ;Datei vorhanden -> weiter
          ld     de,s_loaderr2  ;"Datei kann nicht ge�ffnet werden"
          ld     c,09h          ;Zeichenkette ausgeben
          call   bdos                
          ret  
               
;pr�fen ob es eine PT3 Datei ist
;Datei in Ziel-Puffer schreiben
s_load1:  ld    hl,fcb_ext
          ld    a,(hl)
          cp    'P'
          jr    nz,s_loadx
          inc   hl
          ld    a,(hl)
          cp    'T'
          jr    nz,s_loadx
          inc   hl
          ld    a,(hl)
          cp    '3'
          jr    nz,s_loadx

          ld    hl,song         ;Song-Puffer-Anfang
          ld    (sng_zeig),hl   ;Zeiger auf Song-Puffer

s_load3:  ld    de,fcb
          ld    c,14h           ;sequentiell lesen
          call  bdos
          and   a               ;00 = lesen ok
          jr    nz,playpt3      ;NZ = Dateiende
          ld    hl,dma          ;Quelle DMA
          ld    de,(sng_zeig)   ;Zeiger auf Song-Puffer
          ld    bc,80h          ;Laenge
          ldir                  ;umladen
          ld    (sng_zeig),de   ;Zeiger merken
          jr    s_load3

s_loadx:  ld    de,s_loaderr1   ;"Falsches Dateiformat"
          ld    c,09h           ;Zeichenkette ausgeben
          call  bdos                
          ret
 
        ;SONG LADEN, SPIELEN, STOPPEN:
playpt3:  ld    de,text
          ld    c,09h           ;Zeichenkette ausgeben
          call  bdos
;SONG STARTEN-----------------------
          XOR   A
          LD    (PAUSE),A       ;KEINE PAUSE
          LD    HL,SETUP        ;
          RES   0,(HL)          ;AUTO-LOOP EIN!!!!
          ;SONGADRESSE
          LD    HL,SONG
          LD    (MODADR),HL     ;F�R PLAYER �BERGEBEN
          CALL  PLAY            ;INIT+STARTEN
          HALT                  ;SYNCHR.

loop:    
;SONG FERTIG?----------------------------
          LD    HL,SETUP
          BIT   7,(HL)          ;ENDE-BIT GESETZT?
          JR    NZ,loop2        ;JA
;ABFRAGE TASTATUR------------------------
          CALL  CONSTS
          CP    "X"         
          jr    Z,ende
          CP    "x"
          jr    Z,ende
          JR    loop

loop2:   ;MIT LOOP:-------------------------------
          RES   7,(HL)        
          LD    A,1
          LD    (POSI),A        ;POSI VON VORN!
          BIT   0,(HL)          ;LOOP-BIT=0 GESETZT
          jr    NZ,ende
          JR    loop         
          ;
ENDE:     CALL  STOPP           ;SONG VORZEITIG STOPPEN 
          EI
          LD    SP,(SPSV)       ;alten Stackpointer zur�ckholen
          JP    0               ;R�CKKEHR ZUM OS

CONSTS: ;TASTATURSTATUS, WARTET NICHT
        ;R�CKGABE A=0 WENN KEINE TASTE, SONST CODE
          PUSH  HL
          PUSH  DE
          PUSH  BC
          LD    C,6
          LD    E,0FFH          ;CONSOLENEINGABE
          CALL  5
          POP   BC
          POP   DE
          POP   HL
          RET 

;-------------------------------------------------
text:       defb 0ch,0dh,0ah
            defm ' PLAYPT3 - Version PC1715  (c)WeRo,KW,11/2025 v. 1.0.0.2',0dh,0ah
            defm '--------------------------------------------------------',0dh,0ah,0ah
            defm 'Song wird endlos hintereinander gespielt.... ',0dh,0ah,0ah
            defm 'Abbruch und zurueck zum CP/M mit Taste "X" $'
                    
s_loaderr1: defm 'Falsches Dateiformat ... muss .PT3 sein!$'
s_loaderr2: defm 'Datei kann nicht geoeffnet werden!',0dh,0ah
            defm 'Datei nicht vorhanden oder Dateiname falsch!',0dh,0ah 
            defm '... Dateiname mit Endung .PT3 angeben...$'

;LOKALER STACK (50h)
SPSV:     DEFM   0000h          ;Merker f�r Stackpointer
          DEFS   50h            ;lokaler Stack  
STACK:

PROGEND:

;Arbeitszellen AY-Player
DEFS      128
;-------------------------------------------------
;AY-PLAYER-ENGINE

INCLUDE     PT3_TIM2.INC        ;SPIELDAUERBERECHNUNG
;NAMENSBEZ�GE!
;(MODADR)                       ;�BERGABE SONGADRESSE
;CALL CALC                      ;BERECHNUNG, R�CKGABE: H=MINUTEN, L=SEKUNDEN
;(PT3TIME)                      ;R�CKGABE SPIELDAUER ALS ANZAHL INTERRUPTS
;
INCLUDE     PT3_1715.INC  
;
;PT3-Player Bez�ge...
;CALL PLAY          ;init CTC, init song, play
;CALL STOPP         ;Abspiel Stoppen, INT. aus
;CALL MUTE          ;stummschalten
;(MODADR)           ;WORD   SONGADRESSE
;(SETUP)            ;BYTE   setup und status flags
;(CrPsPtr)          ;WORD   Adresse mit Akt. Pattern
;(POSI)             ;BYTE   LFD. NR. in Positionsliste
;;TON_A:    EQU     AYREGS  TONH�HE
;;TON_B:    EQU     AYREGS+2
;;TON_C:    EQU     AYREGS+4
;RAUSCH:    EQU     AYREGS+6
;MIXER:     EQU     AYREGS+7 
VOL_A:      EQU     AYREGS+8    ;LAUTST�RKE
VOL_B:      EQU     AYREGS+9
VOL_C:      EQU     AYREGS+10
;HK_D:      EQU     AYREGS+11
;HK_F:      EQU     AYREGS+13
;PORTA:     EQU     AYREGS+14
;PORTB:     EQU     AYREGS+15

PLAYEREND:
          
;-------------------------------------------------
SNG_ZEIG:   EQU     PLAYEREND+1
;SONG-BEGINN 
SONG:       EQU     SNG_ZEIG+2  ;HIER BEGINNT GELADENER SONG
;-------------------------------------------------
;
