;Version f�r PC1715 unter CP/A
;Assembler ASIDE
;-------------------------------------------------
;TESTGENERATOR AY-3-8910
;-------------------------------------------------
;ERZEUGT CA. 1KHZ RECHTECK BEI 2 MHZ AY-TAKT
;F�R EXAKTE ODER ANDERE TONH�HE GGF. DEN REGISTERWERT 
;"7DH" BEI H�HE A, /B, /C VARIIEREN!
;-------------------------------------------------
;WERO 09/2017
;KW 28.12.2017
;-------------------------------------------------
;
;Version 1.2.0.2 f�r den PC1715 mit CP/A
;
;KW 24.11.2025
;IO-Adresse der Soundkarte auf E0h ge�ndert
;
;Anpassung an K1520-Soundkarte unter CP/M 
;Auswahl AY-Taktfrequenz, Test der Ton und Ger�uschausgabe  
;-------------------------------------------------
;ANPASSEN AN JEWEILIGES RECHNERSYSTEM:

START:  EQU     100h            ;PROGRAMMSTART
WORK:   EQU     START+10h       ;BEGINN ARBEITSZELLEN (50h)
PLAYER: EQU     WORK+50h        ;BEGINN PLAYER-ENGINE (480h)

AYBASE: EQU     0E0h            ;BASISADRESSE AY-3

;f�r CP/M
raus:   equ     0               ;R�CKSPRUMG ZUM OS 
bdos:   equ     5               ;BDOS AUFRUF
;(ANGEGEBENE WERTE G�LTIG F�R CP/M)
;-------------------------------------------------
ORG     0100h                   ;Anfang CP/M
        JP      START0
;-------------------------------------------------
ORG     WORK                    ;ARBEITSZELLEN, BEZ�GE:
        ;WORK                   ;WORD, �BERGABE ANFANGSADESSE SONG
        ;WORK+2                 ;BYTE, �BERGABE ANZAHL ABSPIELE
                                ;(1...255, 0 BEI SONGENDE)
;-------------------------------------------------
ORG     PLAYER                  ;BEZ�GE:
        ;PLAYER+0               ;SONG LADEN+ABSPIELEN
        ;PLAYER+3               ;GERAEUSCH / TOM AUSGEBEN
        ;PLAYER+6               ;SOUND AUS
;-------------------------------------------------
INCLUDE AYPBC.INC               ;AY-PLAYER-ENGINE
;-------------------------------------------------

;AY-Takt w�hlen
START0: ld      de,TEXT1
        call    disp_str        ;Zeichenkette ausgeben
start1: call    kbwait          ;Taste - Zeichen in A
        ld      b,06Dh          ;1,75MHz AY-Takt 
        cp      "A"             ;Taste "A"?
        jr      z,taset         ;ja => 
        cp      "a"
        jr      z,taset
        ld      b,06Fh          ;1,77MHz AY-Takt
        cp      "B"
        jr      z,taset
        cp      "b"
        jr      z,taset
        ld      b,07Dh          ;2,00MHz AY-Takt
        cp      "C"
        jr      z,taset
        cp      "c"
        jr      z,taset
        jp      start1
taset:  ld      a,b             ;Wert in Registertabelle schreiben
        ld      (TONA),a
        ld      (TONB+2),a
        ld      (TONC+4),a
        ld      (HUBI),a
;
;Ton- und Ger�uschausgabe
start2: LD      DE,TEXT2
        call    disp_str        ;Zeichenkette ausgeben
start3: call    kbwait          ;Taste - Zeichen in A
        LD      HL,TONA         ;ADRESSE REGISTERWERTE
        LD      (WORK),HL
        CP      "A"             ;TASTE "A"?
        CALL    Z,PLAYER+3      ;JA => TON STARTEN
        CP      "a"
        CALL    Z,PLAYER+3
        LD      HL,TONB  
        LD      (WORK),HL
        CP      "B"
        CALL    Z,PLAYER+3
        CP      "b"
        CALL    Z,PLAYER+3 
        LD      HL,TONC
        LD      (WORK),HL  
        CP      "C"
        CALL    Z,PLAYER+3
        CP      "c"
        CALL    Z,PLAYER+3
        LD      HL,HUBI
        LD      (WORK),HL
        CP      "H"
        CALL    Z,PLAYER+3
        CP      "h"
        CALL    Z,PLAYER+3 
        LD      HL,MEER
        LD      (WORK),HL
        CP      "M"
        CALL    Z,PLAYER+3
        CP      "m"
        CALL    Z,PLAYER+3
        LD      HL,SCHUSS
        LD      (WORK),HL
        CP      "S"
        CALL    Z,PLAYER+3
        CP      "s"
        CALL    Z,PLAYER+3 
        LD      HL,AUS
        LD      (WORK),HL  
        CP      "0"
        JP      NZ,start3
        CALL    PLAYER+3        ;AY AUS!
        jp      raus            ;zur�ck zum OS
;--------------------------------------------------
;UP Tastaturabfrage mit Warten
;Zeichen in A
kbwait:   push  bc
          push  de
          push  hl
kbwait1:  ld    c,06      ;zeichen�bernahme in a
          ld    e,0ffh    ;dirkete konsolen e/a
          call  bdos      ;bdos
          cp    0         ;Warten bist Taste gedr�ckt
          jr    z,kbwait1
          pop   hl
          pop   de
          pop   bc
          ret
;--------------------------------------------------
;UP Zeichenkette ausgeben
;Anfangsadresse in DE
;Ende mit "$" = 024h
disp_str: push  hl
          push  de
          push  bc
          push  af
          ld    c,09      ;zeichenkette ausgeben
          call  bdos      ;bdos
          pop   af
          pop   bc
          pop   de
          pop   hl
          ret

;F�R AY-TAKT=2 MHZ: REGISTERWERT #7D F�R CA. 1KHZ
;REGISTER       0     1   2   3   4   5   6   7    8   9   A   B   C   D
;               -H�HEA-   -H�HEB- -H�HEC- R MIX   LA  LB  LC  HDF HDG HKF
TONA:   DEFB    7DH,  0,  0,  0,  0,  0,  0,0FEH,0FH,  0,  0,  0,  0,  0     
TONB:   DEFB      0,  0,7DH,  0,  0,  0,  0,0FDH,  0,0FH,  0,  0,  0,  0     
TONC:   DEFB      0,  0,  0,  0,7DH,  0,  0,0FBH,  0,  0,0FH,  0,  0,  0     
AUS:    DEFB      0,  0,  0,  0,  0,  0,  0,0FFH,  0,  0,  0,  0,  0,  0      
;
;AUCH ALS GER�USCHGENERATOR ZU BENUTZEN, BEISPIELE:
HUBI:   DEFB    6FH,  0,  0,  0,  0,  0,1Eh,0F6H,10H,  0,  0,2CH,  1,0EH 
MEER:   DEFB      0,  0,  0,  0,  0,  0,14H,0CFH,  0,10H,08H,  0,32H,0EH
SCHUSS: DEFB      0,  0,  0,  0,  0,  0,14H,0EFH,  0,10H,  0,  0,1FH,01H
;--------------------------------------------------
TEXT1:  DEFB    0CH
        DEFM    "*  TEST K1520-SOUND-Karte mit AY-3-8910/12 *",0DH,0AH
        DEFM    "*     Version 1.2.0.2  WERO, KW 11/2025    *",0DH,0AH
        DEFM    "--------------------------------------------",0DH,0AH,0DH,0AH
        DEFM    "AUSWAHL TAKTFREQUENZ AY-CHIP:",0DH,0AH,0DH,0AH
        DEFM    "  A=1,75MHz",0DH,0AH
        DEFM    "  B=1,79MHz",0DH,0AH
        DEFM    "  C=2,00MHz",0DH,0AH,0DH,0AH
        DEFM    "WAHL?",024h
;
TEXT2:  DEFB    0CH
        DEFM    "* TEST TON AY-3-8910/12 ca. 1KHz Rechteck *",0DH,0AH
        DEFM    "LAUTSTAERKE: MAXIMAL",0DH,0AH
        DEFM    "-------------------------------------------",0DH,0AH
        DEFM    "  A=RECHTS",0DH,0AH
        DEFM    "  B=BEIDE",0DH,0AH
        DEFM    "  C=LINKS",0DH,0AH,0DH,0AH
        DEFM    "* TEST SOUNDEFFEKTE *",0DH,0AH
        DEFM    "----------------------",0DH,0AH
        DEFM    "  H=HUBSCHRAUBER",0DH,0AH
        DEFM    "  M=MEERESRAUSCHEN",0DH,0AH
        DEFM    "  S=SCHUSS",0DH,0AH,0DH,0AH
        DEFM    "  0=AUS",0DH,0AH,0DH,0AH
        DEFM    "WAHL?",024h

