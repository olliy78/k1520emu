copy /b "tgcpm.bin" "TGCPM.COM"
