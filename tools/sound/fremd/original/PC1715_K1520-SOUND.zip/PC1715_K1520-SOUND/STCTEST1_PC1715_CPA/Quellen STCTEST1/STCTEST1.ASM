;Version f�r PC1715 unter CP/A
;-------------------------------------------------
;GER�ST F�R STC-PLAYER MIT INCLUDE-DATEI
;ASSEMBLER: ASIDE
;WERO, 08/2017
;KW 16.12.2017 (Klaus Wilfling)
;-------------------------------------------------;
;
;Version 1.2.0.2 f�r den PC1715 mit CP/A
;
;KW 24.11.2025
;IO-Adresse der Soundkarte auf E0h ge�ndert (AYPBC.INC)
;
;Song wird gestarte und Programm beendet (l�uft im Hintergrund)
;-------------------------------------------------
;ZUN�CHST ANPASSUNG DER AYPBC.INC (AYPLAY.INC von WERO) 
;AN JEWEILIGES SYSTEM VORNEHMEN:
;HINWEIS CTC-PROGRAMMIERUNG BEACHTEN!
;X0001:   EQU    #aa              ;AY-BASISADRESSE ANPASSEN
;X0002:   EQU    #cc              ;CTC-BASISADRESSE ANPASSEN
;X0003:   EQU    #IIII            ;INTERRUPTTABELLE CTC 
;-------------------------------------------------
START:    EQU     100h            ;PROGRAMMSTART CP/M
WORK:     EQU     0110h           ;BEGINN ARBEITSZELLEN (50h)
PLAYER:   EQU     WORK+0050h      ;BEGINN PLAYER-ENGINE (480h)
PROGGI:   EQU     PLAYER+0480h    ;PROGRAMMBEGINN
WDH:      EQU     WORK+02         ;BYTE, ANZAHL WIEDERHOLUNGEN
;
ANZ_WDH:  EQU     2               ;ANZAHL WIEDERHOLUNGEN
;
;-------------------------------------------------
ORG       START                   ;Anfang CP/M
          JP      START0
;-------------------------------------------------
ORG       WORK                    ;ARBEITSZELLEN, BEZ�GE:
          ;WORK                   ;WORD, �BERGABE ANFANGSADESSE SONG
          ;WORK+2                 ;BYTE, �BERGABE ANZAHL ABSPIELE
                                  ;(1...255, 0 BEI SONGENDE)
;-------------------------------------------------
ORG       PLAYER                  ;BEZ�GE:
          ;PLAYER+0               ;SONG LADEN+ABSPIELEN
          ;PLAYER+6               ;SOUND AUS
;-------------------------------------------------
INCLUDE   AYPBC.INC               ;AY-PLAYER-ENGINE
;-------------------------------------------------
ORG       PROGGI
START0:   ;...HIER ANWENDERPROGRAMM
          ;...VORARBEITEN...
          ;
          ;SONG LADEN, SPIELEN, STOPPEN:
          LD      HL,SONG         ;ANFANGSADRESSE SONG
          LD      (WORK),HL       ;�BERGEBEN
          LD      A,ANZ_WDH       ;ANZAHL ABSPIELE (Z.B. 2x)
          LD      (WDH),A         ;�BERGEBEN
          CALL    PLAYER          ;SONG ABSPIELEN
          ;...SONG L�UFT SELSTBST�NDIG WEITER!
          ;NUN IRGEND ETWAS TUN...ODER AUCH NICHT...
          ;WENN SONG ZUENDE, WIRD INTERRUPT AUTOMATISCH GESTOPPT
          ;
          ;CALL   PLAYER+6        ;SONG VORZEITIG STOPPEN 
          ;...
          RET                     ;R�CKKEHR ZUM OS
;-------------------------------------------------
SONG:   
INCLUDEBINARY MUSIC.STC         ;HIER ABZUSPIELENDEN SONG EINBINDEN
