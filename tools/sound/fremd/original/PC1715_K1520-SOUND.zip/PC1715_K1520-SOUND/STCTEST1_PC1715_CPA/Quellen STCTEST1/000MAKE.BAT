copy /b "stctest1.bin" "STCTEST1.COM"
