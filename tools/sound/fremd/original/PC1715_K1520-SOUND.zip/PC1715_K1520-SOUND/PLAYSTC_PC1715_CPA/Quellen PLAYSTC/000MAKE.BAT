copy /b "playstc.bin" "PLAYSTC.COM"
