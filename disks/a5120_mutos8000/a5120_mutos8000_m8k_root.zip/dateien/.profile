PATH=:/mnt/bin:/usr/bin:/bin:/etc:/mnt/etc:/tmp/bin:/mnt:/usr:/tmp
export PATH
stty length 23 width 80
date
