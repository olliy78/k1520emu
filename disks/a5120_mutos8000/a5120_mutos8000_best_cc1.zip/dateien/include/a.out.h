struct	exec {
	int     	a_magic;
	unsigned	a_text;
	unsigned	a_data;
	unsigned	a_bss;
	unsigned	a_syms;
	unsigned	a_entry;
	unsigned	a_unused;
	unsigned	a_flag;
};
#define	A_MAGIC1	0xE807
#define	A_MAGIC3	0xE811
#define	A_MAGIC4	0xE805
#define	AF_STRIP	0x0001
struct	nlist {
	char    	n_name[8];
	char     	n_type;
	char		n_unused;
	unsigned	n_value;
};
#define	N_UNDF	0x00
#define	N_ABS	0x01
#define	N_TEXT	0x02
#define	N_DATA	0x03
#define	N_BSS	0x04
#define	N_TYPE	0x1F
#define	N_REG	0x14
#define	N_SN	0x1E
#define	N_FN	0x1F
#define	N_EXT	0x20
#define	FORMAT	"%06x"
