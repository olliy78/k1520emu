/*
 * Structure for stty and gtty system calls.
 */

struct sgttyb {
	char	sg_ispeed;		/* input speed */
	char	sg_ospeed;		/* output speed */
	char	sg_erase;		/* erase character */
	char	sg_kill;		/* kill character */
	short	sg_flags;		/* mode flags */
	char	sg_nldly;		/* delay for nl */
	char	sg_crdly;		/* delay for cr */
	char	sg_htdly;		/* delay for ht */
	char	sg_vtdly;		/* delay for vt */
	char	sg_width;		/* screen width */
	char	sg_length;		/* screen length */
};

/*
 * List of special characters
 */
