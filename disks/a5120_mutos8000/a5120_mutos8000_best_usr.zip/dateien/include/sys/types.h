typedef long		daddr_t;
typedef char *		caddr_t;
typedef unsigned int	ino_t;
typedef long		time_t;
typedef int		label_t[6];
typedef int		dev_t;
typedef long		off_t;
#define major(x)	(int)(((unsigned)x>>8))
#define minor(x)	(int)(x&0377)
#define makedev(x,y)	(dev_t)((x)<<8|(y))
